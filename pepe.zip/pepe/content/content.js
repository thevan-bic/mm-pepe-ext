function triggerInputChange(node, value = '', cb) {
    if ([window.HTMLTextAreaElement].indexOf(node.__proto__.constructor) > -1) {
        const setValue = Object.getOwnPropertyDescriptor(node.__proto__, 'value').set;
        const event = new Event('input', {bubbles: true});
        setValue.call(node, value);
        node.dispatchEvent(event);
        if(cb) {
            cb(value);
        }
    }
}

function getCollections(cb) {
    chrome.runtime.sendMessage({cmd: "get_collections"}, function (collections) {
        cb(collections);
    });
}

function addMainChannel(control, wrapper) {

    const parent = wrapper.attr('id');

    const openPepeTemplate = (parent, index) => `
      <button id="open-pepe-${parent}-${index}" data-index="${parent}-${index}" class="pepe ppp-${parent}" type="button" aria-label="select a pepe emoji">
          <span class="pepe-title">
              Pepe Emoji
          </span>
          <img  src="https://cdn3.emoji.gg/emojis/6810-pepeshhhh.png" width="16px" height="16px" alt="pepeshhhh"/>
      </button>
    `;

    const pepeEmojiListTemplate = (parent, index) => `
      <div id="pepe-emoji-picker-${parent}-${index}" class="pepe-emoji-picker">init</div>
  `;

    const index = 0;
    if ($(`#open-pepe-${parent}-${index}`).length > 0) {
        return;
    }

    control.append(openPepeTemplate(parent, index));

    $(`#open-pepe-${parent}-${index}`).append(pepeEmojiListTemplate(parent, index));
    firstRun = false
    $(document).on('click', `#open-pepe-${parent}-${index}`, function (e) {
        e.stopPropagation();

        const i = $(this).data('index');

        const tab = `#pepe-emoji-picker-${i}`;

        $(document).on('click', `*:not(.ppp-${parent}, ${tab})`, function (e) {
            $(tab).hide();
        });

        if ($(tab).length && $(tab).text() !== 'init') {
            $(tab).show();
            return;
        }
        getCollections(function (collections) {
            const data = collections['pepe.collections'] ?? [];
            if (!data.length) {
                return;
            }
            let domTpl = data.map(d => d.emotes).flat();

            domTpl.unshift({
                name: 'Pepe knife',
                url: 'https://cdn3.emoji.gg/emojis/monkaStab.png'
            });

            domTpl = domTpl.map(({name, url}) => {
                return `<div class="pepe-emoji-item pp-${parent}" style="display: inline"  data-name="${name}" data-url="${url}">
                                <img src="${url}" alt="${name}">
                            </div>`
            }).join('\n');


            $(tab).html(domTpl);

            $(tab).css('display', 'block');


            $(document).on('click', `.pp-${parent}`, function (e) {
                e.stopPropagation();
                const name = $(this).data('name');
                const url = $(this).data('url');
                const emoji = `![${name}](${url})`;
                const input = $($(this).closest('form')[0][0]);
                const value = input.text() + emoji;
                triggerInputChange(input[0], value, function (e) {});
                $(tab).hide();
                input.focus();
            });

        });
    })

}

function deleteButton(parent,index) {
    $(`#open-pepe-${parent}-${index}`).remove();
}

function addReplyChannel(control, wrapper) {
    const parent = wrapper.attr('class');
    
    const openPepeTemplate = (parent, index) => `
      <button id="open-pepe-${parent}-${index}" data-index="${parent}-${index}" class="pepe ppp-${parent}" type="button" aria-label="select a pepe emoji">
          <span class="pepe-title">
              Pepe Emoji
          </span>
          <img  src="https://cdn3.emoji.gg/emojis/6810-pepeshhhh.png" width="16px" height="16px" alt="pepeshhhh"/>
      </button>
    `;
    const pepeEmojiListTemplate = (parent, index) => `
      <div id="pepe-emoji-picker-${parent}-${index}" class="pepe-emoji-picker">init</div>
      `;

    const index = 0;
    if ($(`#open-pepe-${parent}-${index}`).length > 0) {
        return;
    }
    control.append(openPepeTemplate(parent, index));

    $(`#open-pepe-${parent}-${index}`).append(pepeEmojiListTemplate(parent, index));

    if(firstRunReply) {
        return
    }


    $(document).on('click', `#open-pepe-${parent}-${index}`, function (e) {
        e.stopPropagation();

        const i = $(this).data('index');
        const tab = `#pepe-emoji-picker-${i}`;

        $(document).on('click', `*:not(.pepe, ${tab})`, function (e) {
            $(tab).hide();
        });

        if ($(tab).length && $(tab).text() !== 'init') {
            $(tab).show();
            return;
        }
        getCollections(function (collections) {
            const data = collections['pepe.collections'] ?? [];

            if (!data.length) {
                return;
            }


            let domTpl = data.map(d => d.emotes).flat();

            domTpl.unshift({
                name: 'Pepe knife',
                url: 'https://cdn3.emoji.gg/emojis/monkaStab.png'
            });

            domTpl = domTpl.map(({name, url}) => {
                return `<div class="pepe-emoji-item pp-${parent}" style="display: inline"  data-name="${name}" data-url="${url}">
                                <img src="${url}" alt="${name}">
                            </div>`
            }).join('\n');


            $(tab).html(domTpl);

            $(tab).css('display', 'block');


            $(document).one('click', `.pp-${parent}`, function (e) {
                e.stopPropagation();
                const name = $(this).data('name');
                const url = $(this).data('url');
                const emoji = `![${name}](${url})`;
                const input = $($(this).closest('form')[0][0]);
                const value = input.text() + emoji;
                triggerInputChange(input[0], value);
                $(tab).hide();
                input.focus();
            });

        });
    })

    firstRunReply = true;
}

let firstRunReply = false;

let firstRun = true;

function init() {
    $('#threads-list-container').on('click','.ThreadItem', function (e) {
        e.stopPropagation();
        const self = this;
        setTimeout(function () {
            const threadViewer = $(self).closest('#threads-list-container').next().find('.ThreadItem');
            if (threadViewer && firstRunReply) {
                deleteButton(threadViewer.attr('css'),0);
                const control = threadViewer.find('[class^="FormattingBarContainer-"]');
                if (control && control.length) {
                    addReplyChannel(control, threadViewer);
                }
            }
        },100);
    });

    const observer = new MutationObserver(function (mutations, mutationInstance) {

        const postCreate = $('#create_post');
        const threadViewer = $('.ThreadViewer');

        if (postCreate && firstRun) {
        
            const control = postCreate.find('[class^="FormattingBarContainer-"]');
            if (control && control.length) {
                addMainChannel(control, postCreate);
            }
        }

        if (threadViewer) {
            const control = threadViewer.find('[class^="FormattingBarContainer-"]');
            if (control && control.length) {
                addReplyChannel(control, threadViewer);
            }
        }else {
            threadViewer.remove()
        }
    });

    observer.observe(document, {
        childList: true,
        subtree: true
    });
}

(function ($) {
    init();
})(jQuery)