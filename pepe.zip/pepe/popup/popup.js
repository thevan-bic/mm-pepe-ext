
function parseDara(text) {
   const arr =  text.split(",");
   return arr.map(pack => (pack ? pack : '').trim());
}

async function savePacks(data) {
    return new Promise((resolve,reject) => {
        chrome.runtime.sendMessage({cmd: "save_packs",data: data}, function (response) {
            resolve(response)
        });
    }) 
}

async function getPacks(data) {
    return new Promise((resolve,reject) => {
        chrome.runtime.sendMessage({cmd: "get_packs"}, function (response) {
            resolve(response)
        });
    }) 
}


(function ($) {

    getPacks().then(packs => {
        $('#pack-value').val(packs.join(','));
    })

   $('#btn-save-pack').on('click', function(e) {
    const value = $('#pack-value').val();
    if(!value) {

        return;
    }
    const data  = parseDara(value);
    
    savePacks(data).then((res)=> {
        console.log(res)
    }).catch(err=> {
        console.log(err)
    })

   })
})(jQuery)