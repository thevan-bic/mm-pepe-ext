
async function savePacks(data) {
    console.log('savePacks',data)
  return new Promise((rs,rj) => {
    chrome.storage.local.set({packs: data}, () => {
        if (chrome.runtime.lastError) {
            return rj(false);
        }
        getAllPack().then((data)=> {

            chrome.storage.local.set({"pepe.collections": data}, () => {
                if (chrome.runtime.lastError) {
                    console.log('Error setting');
                }
                console.log('Stored name: ' + "pepe.collections");
          })
          rs(true)
        });
    })
  }) 
}

async function getEmojiCollections(collectionName) {
    try {
        const result = await fetch(`https://emoji.gg/pack/${collectionName}&type=json`);
        return result.json();
    } catch (e) {
        return {}
    }
}

async function getAllPack() {

    const data = await (new Promise((rs,rj) => {
        chrome.storage.local.get("packs", (result) => {
            if(result && result.packs.length) {
                rs(result.packs);
            }
            rs([
                '9113-sassycat-emotes',
                '5761-cat-memes',
                '2486-mad-pepe-pack',
                '4167-pepe-sad-pack',
                '9284-pepe',
                '4108-pepe',
                '8572-pepe',
                '6406-pepe-emotes-pack',
                '6994-pepe-love-pack',
                '7874-creepy-pepe-pack',
                '8862-pepe-police-pack',
                '3315-umks-pepe-emoji-collection',
                '2767-pepesign','8198-pepe-pack','1292-pepemoji-gif-set-1'
            ]);
         })
    }))
     return Promise.all(data.map(collection => getEmojiCollections(collection)));
}

getAllPack().then((data)=> {

    chrome.storage.local.set({"pepe.collections": data}, () => {
        if (chrome.runtime.lastError) {
            console.log('Error setting');
        }
        console.log('Stored name: ' + "pepe.collections");
  })

});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if(request.cmd == "get_collections") {
        chrome.storage.local.get("pepe.collections",sendResponse);
    }
    
    if(request.cmd == "get_packs") {
        chrome.storage.local.get("packs", (result) => {
            if(result && result.packs.length) {
                sendResponse(result.packs);
            }
            sendResponse(['9113-sassycat-emotes',
            '5761-cat-memes',
            '2486-mad-pepe-pack',
            '4167-pepe-sad-pack',
            '9284-pepe',
            '4108-pepe',
            '8572-pepe',
            '6406-pepe-emotes-pack',
            '6994-pepe-love-pack',
            '7874-creepy-pepe-pack',
            '8862-pepe-police-pack',
            '3315-umks-pepe-emoji-collection',
            '2767-pepesign','8198-pepe-pack','1292-pepemoji-gif-set-1']);
         })
    }

    if(request.cmd == "save_packs") {
        savePacks(request.data).then(sendResponse).catch(sendResponse);
    }

    return true;
});